export default {
  primary: "#bf3334",
  secondary: "#d9c148",
  dark: "#122622",
  light: "#81a69b",
  accent: "#122622"
};
